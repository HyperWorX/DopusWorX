# DopusWorX — animated hero banner

Self-contained hero banner for the DopusWorX README. No build step, no
dependencies — just open `index.html` in a browser.

## Files
- `index.html` — the banner (1280×600). All styling is inline in the file.
- `assets/` — the logo + the app screenshots used in the scrolling wall.

## The animation
The only motion is the **background wall** of app pages drifting up/down.
It is a **seamless loop**: the first frame is identical to the last, so a
recorded GIF/video repeats with no jump. The centered logo lockup is static.

- **Loop length** is one value: `--loop` on `.stage` (default `18s`).
- To record a looping GIF/MP4, capture exactly one `--loop` period.

## Using it in a README
Drop a recorded `.gif` / `.mp4` next to your README and reference it:

```md
![DopusWorX](DopusWorX-hero.gif)
```

(GitHub also renders `.mp4`/`.mov` dragged into a README.)
